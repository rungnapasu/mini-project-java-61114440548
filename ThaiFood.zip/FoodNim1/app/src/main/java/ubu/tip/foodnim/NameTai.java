package ubu.tip.foodnim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class NameTai extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name_tai);
        Intent intent = getIntent();
        String fruitName = intent.getStringExtra("foodName");

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        layoutParams.setMargins(40,30,30,30);
        linearLayout.setLayoutParams(linearParams);
        scrollView.addView(linearLayout);


        String[] foodTai = {"สะตอผัดกะปิ","ปลาเค้าทอดขมิ้น","หมูผัดตำลึง","ผัดเผ็ดไก่กับสะตอ","ผัดเผ็ดปลากระทิงย่าง","ผัดผักเหลียงใส่ไข่","แกงกะทิไก่กับกล้วยดิบ","ผัดถั่วฝักยาวกับปลาฉิ้งฉ้างทอดกรอบ","ผัดเผ็ดสะตออกไก่","แกงน้ำเคยทรงเครื่อง",
                "แกงกะทิมันขี้หนูกับปลาดุกนา","แกงส้มปลาจีนกับปลาบึกใส่มันขี้หนู","แกงกะทิหมูกับมะเขือพวง","พร้าวปิ้ง","แกงส้มหมูย่างกับลูกกล้วย","ต้มกะทิไข่มดแดง","ฉู่ฉี่ปลาปลาทู","แกงปูใส่ใบชะพลู","ปลากระเบนผัดหัวกะทิ","แกงส้มอ้อดิบ"};

        for (final String i : foodTai) {


            TextView textView1 = new TextView(this);
            LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params1.setMargins(50, 30, 0, 30);
            params1.gravity = Gravity.CENTER;
            textView1.setLayoutParams(params1);
            textView1.setTextSize(18);
            textView1.setText(i);
            linearLayout.addView(textView1);
            textView1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(NameTai.this, FoodShowTai.class);
                    intent.putExtra("foodName", i);
                    startActivity(intent);
                    Toast toast = Toast.makeText(getApplicationContext(),
                            i,
                            Toast.LENGTH_LONG);
                    toast.show();
                }});





        }

        LinearLayout linearLayout1 = findViewById(R.id.rootContainer4);
        if (linearLayout1 != null) {
            linearLayout1.addView(scrollView);
        }
    }
}