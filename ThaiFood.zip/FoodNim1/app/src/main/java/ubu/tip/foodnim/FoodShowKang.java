package ubu.tip.foodnim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
public class FoodShowKang extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_show_kang);
        Intent intent = getIntent();
        String foodName = intent.getStringExtra("foodName");

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        layoutParams.setMargins(50,30,30,30);
        linearLayout.setLayoutParams(linearParams);
        scrollView.addView(linearLayout);
        TextView textView = new TextView(this);
        textView.setTextSize(16);

        TextView name_manu = new TextView(this);
        LinearLayout.LayoutParams name_params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        name_params.setMargins(0, 30 ,0, 30);
        name_params.gravity = Gravity.CENTER;
        name_manu.setGravity(Gravity.CENTER);
        name_manu.setTextSize(28);
        name_manu.setLayoutParams(name_params);
        linearLayout.addView(name_manu);

        if (foodName.equals("ไก่ผัดขิง")){
            textView.setText(getString(R.string.ไก่ผัดขิง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ไก่ผัดขิง");
        }
        if (foodName.equals("แกงปลากรายใส่มะเขือยาว")){
            textView.setText(getString(R.string.แกงปลากรายใส่มะเขือยาว));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงปลากรายใส่มะเขือยาว");
        }
        if (foodName.equals("ผัดผักรวมน้ำมันหอย")){
            textView.setText(getString(R.string.ผัดผักรวมน้ำมันหอย));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ผัดผักรวมน้ำมันหอย");
        }
        if (foodName.equals("แกงส้มไข่ทอดชะอมใส่กุ้ง")){
            textView.setText(getString(R.string.แกงส้มไข่ทอดชะอมใส่กุ้ง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงส้มไข่ทอดชะอมใส่กุ้ง");
        }
        if (foodName.equals("ต้มข่าไก่ใส่หัวปลี")){
            textView.setText(getString(R.string.ต้มข่าไก่ใส่หัวปลี));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ต้มข่าไก่ใส่หัวปลี");
        }
        if (foodName.equals("ต้มยำปลาเค้าน้ำใส")){
            textView.setText(getString(R.string.ต้มยำปลาเค้าน้ำใส));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ต้มยำปลาเค้าน้ำใส");
        }
        if (foodName.equals("แกงป่าปลากราย")){
            textView.setText(getString(R.string.แกงป่าปลากราย));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงป่าปลากราย");
        }
        if (foodName.equals("แกงจืดมะระยัดไส้ไก่สับ")){
            textView.setText(getString(R.string.แกงจืดมะระยัดไส้ไก่สับ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงจืดมะระยัดไส้ไก่สับ");
        }
        if (foodName.equals("ผัดเผ็ดกุ้ง")){
            textView.setText(getString(R.string.ผัดเผ็ดกุ้ง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ผัดเผ็ดกุ้ง");
        }
        if (foodName.equals("ต้มยำปลากระพง")){
            textView.setText(getString(R.string.ต้มยำปลากระพง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ต้มยำปลากระพง");
        }
        if (foodName.equals("แกงจืดมะระใส่ผักกาดดอง")){
            textView.setText(getString(R.string.แกงจืดมะระใส่ผักกาดดอง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงจืดมะระใส่ผักกาดดอง");
        }
        if (foodName.equals("ปลาเก๋าผัดพริก")){
            textView.setText(getString(R.string.ปลาเก๋าผัดพริก));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ปลาเก๋าผัดพริก");
        }
        if (foodName.equals("ปูผัดผงกะหรี่่")){
            textView.setText(getString(R.string.ปูผัดผงกะหรี่่));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ปูผัดผงกะหรี่่");
        }
        if (foodName.equals("หลนปลาเค็ม")){
            textView.setText(getString(R.string.หลนปลาเค็ม));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("หลนปลาเค็ม");
        }
        if (foodName.equals("ผัดฉ่าหอยแมลงภู่")){
            textView.setText(getString(R.string.ผัดฉ่าหอยแมลงภู่));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ผัดฉ่าหอยแมลงภู่");
        }
        if (foodName.equals("แกงเทโพกับปลาซูยี")){
            textView.setText(getString(R.string.แกงเทโพกับปลาซูยี));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงเทโพกับปลาซูยี");
        }
        if (foodName.equals("ไก่หวาน")){
            textView.setText(getString(R.string.ไก่หวาน));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ไก่หวาน");
        }
        if (foodName.equals("ปลาหมึกต้มดำ")){
            textView.setText(getString(R.string.ปลาหมึกต้มดำ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ปลาหมึกต้มดำ");
        }
        if (foodName.equals("ข้าวหมกปลาอินทรี")){
            textView.setText(getString(R.string.ข้าวหมกปลาอินทรี));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ข้าวหมกปลาอินทรี");
        }
        if (foodName.equals("แกงคั่วหอยลาย")){
            textView.setText(getString(R.string.แกงคั่วหอยลาย));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงคั่วหอยลาย");
        }

        LinearLayout linearLayout1 = findViewById(R.id.showkang);
        if (linearLayout1 != null) {
            linearLayout1.addView(scrollView);
        }
    }
}