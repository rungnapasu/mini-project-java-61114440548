package ubu.tip.foodnim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class FoodShowTai extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_show_tai);
        Intent intent = getIntent();
        String foodName = intent.getStringExtra("foodName");

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        layoutParams.setMargins(50,30,30,30);
        linearLayout.setLayoutParams(linearParams);
        scrollView.addView(linearLayout);
        TextView textView = new TextView(this);
        textView.setTextSize(16);

        TextView name_manu = new TextView(this);
        LinearLayout.LayoutParams name_params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        name_params.setMargins(0, 30 ,0, 30);
        name_params.gravity = Gravity.CENTER;
        name_manu.setGravity(Gravity.CENTER);
        name_manu.setTextSize(28);
        name_manu.setLayoutParams(name_params);
        linearLayout.addView(name_manu);


        if (foodName.equals("สะตอผัดกะปิ")){
            textView.setText(getString(R.string.สะตอผัดกะปิ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("สะตอผัดกะปิ");
        }
        if (foodName.equals("ปลาเค้าทอดขมิ้น")){
            textView.setText(getString(R.string.ปลาเค้าทอดขมิ้น));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ปลาเค้าทอดขมิ้น");

        }
        if (foodName.equals("หมูผัดตำลึง")){
            textView.setText(getString(R.string.หมูผัดตำลึง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("หมูผัดตำลึง");
        }
        if (foodName.equals("ผัดเผ็ดไก่กับสะตอ")){
            textView.setText(getString(R.string.ผัดเผ็ดไก่กับสะตอ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ผัดเผ็ดไก่กับสะตอ");
        }
        if (foodName.equals("ผัดเผ็ดปลากระทิงย่าง")){
            textView.setText(getString(R.string.ผัดเผ็ดปลากระทิงย่าง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ผัดเผ็ดปลากระทิงย่าง");
        }
        if (foodName.equals("ผัดผักเหลียงใส่ไข่")){
            textView.setText(getString(R.string.ผัดผักเหลียงใส่ไข่));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ผัดผักเหลียงใส่ไข่");
        }
        if (foodName.equals("แกงกะทิไก่กับกล้วยดิบ")){
            textView.setText(getString(R.string.แกงกะทิไก่กับกล้วยดิบ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงกะทิไก่กับกล้วยดิบ");
        }
        if (foodName.equals("ผัดถั่วฝักยาวกับปลาฉิ้งฉ้างทอดกรอบ")){
            textView.setText(getString(R.string.ผัดถั่วฝักยาวกับปลาฉิ้งฉ้างทอดกรอบ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ผัดถั่วฝักยาวกับปลาฉิ้งฉ้างทอดกรอบ");
        }
        if (foodName.equals("ผัดเผ็ดสะตออกไก่")){
            textView.setText(getString(R.string.ผัดเผ็ดสะตออกไก่));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ผัดเผ็ดสะตออกไก่");
        }
        if (foodName.equals("แกงน้ำเคยทรงเครื่อง")){
            textView.setText(getString(R.string.แกงน้ำเคยทรงเครื่อง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงน้ำเคยทรงเครื่อง");
        }
        if (foodName.equals("แกงกะทิมันขี้หนูกับปลาดุกนา")){
            textView.setText(getString(R.string.แกงกะทิมันขี้หนูกับปลาดุกนา));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงกะทิมันขี้หนูกับปลาดุกนา");
        }
        if (foodName.equals("แกงส้มปลาจีนกับปลาบึกใส่มันขี้หนู")){
            textView.setText(getString(R.string.แกงส้มปลาจีนกับปลาบึกใส่มันขี้หนู));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงส้มปลาจีนกับปลาบึกใส่มันขี้หนู");
        }
        if (foodName.equals("แกงกะทิหมูกับมะเขือพวง")){
            textView.setText(getString(R.string.แกงกะทิหมูกับมะเขือพวง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงกะทิหมูกับมะเขือพวง");
        }
        if (foodName.equals("พร้าวปิ้ง")){
            textView.setText(getString(R.string.พร้าวปิ้ง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("พร้าวปิ้ง");
        }
        if (foodName.equals("แกงส้มหมูย่างกับลูกกล้วย")){
            textView.setText(getString(R.string.แกงส้มหมูย่างกับลูกกล้วย));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงส้มหมูย่างกับลูกกล้วย");
        }
        if (foodName.equals("ต้มกะทิไข่มดแดง")){
            textView.setText(getString(R.string.ต้มกะทิไข่มดแดง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ต้มกะทิไข่มดแดง");
        }
        if (foodName.equals("ฉู่ฉี่ปลาปลาทู")){
            textView.setText(getString(R.string.ฉู่ฉี่ปลาปลาทู));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ฉู่ฉี่ปลาปลาทู");
        }
        if (foodName.equals("แกงปูใส่ใบชะพลู")){
            textView.setText(getString(R.string.แกงปูใส่ใบชะพลู));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงปูใส่ใบชะพลู");
        }
        if (foodName.equals("ปลากระเบนผัดหัวกะทิ")){
            textView.setText(getString(R.string.ปลากระเบนผัดหัวกะทิ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ปลากระเบนผัดหัวกะทิ");
        }
        if (foodName.equals("แกงส้มอ้อดิบ")){
            textView.setText(getString(R.string.แกงส้มอ้อดิบ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงส้มอ้อดิบ");
        }

        LinearLayout linearLayout1 = findViewById(R.id.showtai);
        if (linearLayout1 != null) {
            linearLayout1.addView(scrollView);
        }
    }
}
