package ubu.tip.foodnim;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class FoodShowEisan extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_show_eisan);
        Intent intent = getIntent();
        String foodName = intent.getStringExtra("foodName");

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);



        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearParams.setMargins(50,30,30,30);
        linearLayout.setLayoutParams(linearParams);
        scrollView.addView(linearLayout);
        TextView textView = new TextView(this);
        textView.setTextSize(16);


        TextView name_manu = new TextView(this);
        LinearLayout.LayoutParams name_params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        name_params.setMargins(0, 30 ,0, 30);
        name_params.gravity = Gravity.CENTER;
        name_manu.setGravity(Gravity.CENTER);
        name_manu.setTextSize(28);
        name_manu.setLayoutParams(name_params);
        linearLayout.addView(name_manu);


        if (foodName.equals("ไก่บ้านย่างสมุนไพร")){
            textView.setText(R.string.ไก่บ้านย่างสมุนไพร);
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ไก่บ้านย่างสมุนไพร");
        }
        if (foodName.equals("ลาบไส้หมูู")){
            textView.setText(getString(R.string.ลาบไส้หมู));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ลาบไส้หมูู");
        }
        if (foodName.equals("ต้มเห็ดรวมใส่ปลาแห้ง")){
            textView.setText(getString(R.string.ต้มเห็ดรวมใส่ปลาแห้ง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ต้มเห็ดรวมใส่ปลาแห้ง");
        }
        if (foodName.equals("ลาบปลาช่อนทอดกรอบ")){
            textView.setText(getString(R.string.ลาบปลาช่อนทอดกรอบ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ลาบปลาช่อนทอดกรอบ");
        }
        if (foodName.equals("ซุปหน่อไม้")){
            textView.setText(getString(R.string.ซุปหน่อไม้));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ซุปหน่อไม้");
        }
        if (foodName.equals("ลาบปลาดุกย่าง")){
            textView.setText(getString(R.string.ลาบปลาดุกย่าง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ลาบปลาดุกย่าง");
        }
        if (foodName.equals("ไส้อ่อนย่าง")){
            textView.setText(getString(R.string.ไส้อ่อนย่าง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ไส้อ่อนย่าง");
        }
        if (foodName.equals("ลาบเห็ดฟาง")){
            textView.setText(getString(R.string.ลาบเห็ดฟาง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ลาบเห็ดฟาง");
        }
        if (foodName.equals("ต้มแซ่บกระดูกหมูอ่อน")){
            textView.setText(getString(R.string.ต้มแซ่บกระดูกหมูอ่อน));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ต้มแซ่บกระดูกหมูอ่อน");
        }
        if (foodName.equals("ต้มแซ่บตีนไก่ซุปเปอร์")){
            textView.setText(getString(R.string.ต้มแซ่บตีนไก่ซุปเปอร์));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ต้มแซ่บตีนไก่ซุปเปอร์");
        }
        if (foodName.equals("ส้มตำหมูยอ")){
            textView.setText(getString(R.string.ส้มตำหมูยอ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ส้มตำหมูยอ");
        }
        if (foodName.equals("ซี่่โครงแหนมทอด")){
            textView.setText(getString(R.string.ซี่โครงแหนมทอด));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ซี่่โครงแหนมทอด");
        }
        if (foodName.equals("ซี่โครงแหนมทอด")){
            textView.setText(getString(R.string.ซี่โครงแหนมทอด));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ซี่โครงแหนมทอด");
        }
        if (foodName.equals("เสือร้องไห้")){
            textView.setText(getString(R.string.เสือร้องไห้));name_manu.setText("เสือร้องไห้");
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("เสือร้องไห้");
        }
        if (foodName.equals("ยำแหนมสด")){
            textView.setText(getString(R.string.ยำแหนมสด));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ยำแหนมสด");
        }
        if (foodName.equals("กุ้งเต้น")){
            textView.setText(getString(R.string.กุ้งเต้น));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("กุ้งเต้น");
        }
        if (foodName.equals("ตับหวาน")){
            textView.setText(getString(R.string.ตับหวาน));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ตับหวาน");
        }
        if (foodName.equals("หมูแดดเดียว")){
            textView.setText(getString(R.string.หมูแดดเดียว));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("หมูแดดเดียว");
        }
        if (foodName.equals("ยำคอหมูย่าง")){
            textView.setText(getString(R.string.ยำคอหมูย่าง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ยำคอหมูย่าง");
        }
        if (foodName.equals("ปลาช่อนเผาเกลือสอดไส้ผัก3สี")){
            textView.setText(getString(R.string.ปลาช่อนเผาเกลือสอดไส้ผัก3สี));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ปลาช่อนเผาเกลือสอดไส้ผัก3สี");
        }
        if (foodName.equals("ลาบดอกขจร")){
            textView.setText(getString(R.string.ลาบดอกขจร));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ลาบดอกขจร");
        }

        LinearLayout linearLayout1 = findViewById(R.id.showeisan);
        if (linearLayout1 != null) {
            linearLayout1.addView(scrollView);
        }
    }
}