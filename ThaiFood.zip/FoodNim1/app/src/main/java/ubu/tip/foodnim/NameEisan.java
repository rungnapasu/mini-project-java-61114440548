package ubu.tip.foodnim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class NameEisan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name_eisan);
        Intent intent = getIntent();
        String fruitName = intent.getStringExtra("foodName");

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        layoutParams.setMargins(40,30,30,30);
        linearLayout.setLayoutParams(linearParams);
        scrollView.addView(linearLayout);


        String[] foodEisan = {"ไก่บ้านย่างสมุนไพร","ลาบไส้หมูู","ต้มเห็ดรวมใส่ปลาแห้ง","ลาบปลาช่อนทอดกรอบ","ซุปหน่อไม้","ลาบปลาดุกย่าง","ไส้อ่อนย่าง","ลาบเห็ดฟาง","ต้มแซ่บกระดูกหมูอ่อน",
                "ต้มแซ่บตีนไก่ซุปเปอร์","ส้มตำหมูยอ","ซี่โครงแหนมทอด","เสือร้องไห้","ยำแหนมสด","กุ้งเต้น","ตับหวาน","หมูแดดเดียว","ยำคอหมูย่าง","ปลาช่อนเผาเกลือสอดไส้ผัก3สี","ลาบดอกขจร"};

        for (final String i : foodEisan) {


            TextView textView1 = new TextView(this);
            LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params1.setMargins(50, 30, 0, 30);
            params1.gravity = Gravity.CENTER;
            textView1.setLayoutParams(params1);
            textView1.setTextSize(18);
            textView1.setText(i);
            linearLayout.addView(textView1);
            textView1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(NameEisan.this, FoodShowEisan.class);
                    intent.putExtra("foodName", i);
                    startActivity(intent);
                    Toast toast = Toast.makeText(getApplicationContext(),
                            i,
                            Toast.LENGTH_LONG);
                    toast.show();
                }});




        }

        LinearLayout linearLayout1 = findViewById(R.id.rootContainer2);
        if (linearLayout1 != null) {
            linearLayout1.addView(scrollView);
        }
    }
}

