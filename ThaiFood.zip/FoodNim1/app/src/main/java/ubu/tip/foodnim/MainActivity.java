package ubu.tip.foodnim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    MediaPlayer sound;
    MediaPlayer eisan;
    MediaPlayer kang;
    MediaPlayer nuer;
    MediaPlayer tai;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sound = MediaPlayer.create(this,R.raw.t2);
        sound.start();
        sound.setLooping(true);

        eisan = MediaPlayer.create(this,R.raw.t);
        kang = MediaPlayer.create(this,R.raw.t);
        nuer = MediaPlayer.create(this,R.raw.t);
        tai = MediaPlayer.create(this,R.raw.t);


    }



    public void gotokang(View view) {
        Intent intent = new Intent(this, NameKang.class);
        startActivity(intent);
        kang.start();

    }

    public void gotonuer(View view) {
        Intent intent = new Intent(this, NameNuer.class);
        startActivity(intent);
        nuer.start();
    }

    public void gotoeisan(View view) {
        Intent intent = new Intent(this, NameEisan.class);
        startActivity(intent);
        eisan.start();
    }

    public void gotoTai(View view) {
        Intent intent = new Intent(this, NameTai.class);
        startActivity(intent);
        tai.start();
    }
}
