package ubu.tip.foodnim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class FoodShowNuer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_show_nuer);
        Intent intent = getIntent();
        String foodName = intent.getStringExtra("foodName");

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        layoutParams.setMargins(50, 30, 30, 30);
        linearLayout.setLayoutParams(linearParams);
        scrollView.addView(linearLayout);
        TextView textView = new TextView(this);
        textView.setTextSize(16);

        TextView name_manu = new TextView(this);
        LinearLayout.LayoutParams name_params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        name_params.setMargins(0, 30, 0, 30);
        name_params.gravity = Gravity.CENTER;
        name_manu.setGravity(Gravity.CENTER);
        name_manu.setTextSize(28);
        name_manu.setLayoutParams(name_params);
        linearLayout.addView(name_manu);

        if (foodName.equals("น้ำพริกตาแดง")) {
            textView.setText(getString(R.string.น้ำพริกตาแดง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("น้ำพริกตาแดง");
        }
        if (foodName.equals("จอผักปลัง")) {
            textView.setText(getString(R.string.จอผักปลัง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("จอผักปลัง");
        }
        if (foodName.equals("ปูอ่อง")) {
            textView.setText(getString(R.string.ปูอ่อง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ปูอ่อง");
        }
        if (foodName.equals("แอบไก่ดำ")) {
            textView.setText(getString(R.string.แอบไก่ดำ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แอบไก่ดำ");
        }
        if (foodName.equals("แกงอ่อมซี่โครงหมู")) {
            textView.setText(getString(R.string.แกงอ่อมซี่โครงหมู));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงอ่อมซี่โครงหมู");
        }
        if (foodName.equals("ต้มยำปลาช่อน")) {
            textView.setText(getString(R.string.ต้มยำปลาช่อน));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ต้มยำปลาช่อน");
        }
        if (foodName.equals("ตำมะเขือยาว")) {
            textView.setText(getString(R.string.ตำมะเขือยาว));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ตำมะเขือยาว");
        }
        if (foodName.equals("แกงอ่อมหมู")) {
            textView.setText(getString(R.string.แกงอ่อมหมู));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงอ่อมหมู");
        }
        if (foodName.equals("แกงแคปลา")) {
            textView.setText(getString(R.string.แกงแคปลา));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงแคปลา");
        }
        if (foodName.equals("น้ำพริกอ่อง")) {
            textView.setText(getString(R.string.น้ำพริกอ่อง));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("น้ำพริกอ่อง");
        }
        if (foodName.equals("ลาบคั่ว")) {
            textView.setText(getString(R.string.ลาบคั่ว));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ลาบคั่ว");
        }
        if (foodName.equals("น้ำพริกแกงน้ำเงี้ยว")) {
            textView.setText(getString(R.string.น้ำพริกแกงน้ำเงี้ยว));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("น้ำพริกแกงน้ำเงี้ยว");
        }
        if (foodName.equals("แกงขนุนอ่อน")) {
            textView.setText(getString(R.string.แกงขนุนอ่อน));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงขนุนอ่อน");
        }
        if (foodName.equals("รถด่วนทอด")) {
            textView.setText(getString(R.string.รถด่วนทอด));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("รถด่วนทอด");
        }
        if (foodName.equals("แกงโฮะ")) {
            textView.setText(getString(R.string.แกงโฮะ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงโฮะ");
        }
        if (foodName.equals("แกงฮังเล")) {
            textView.setText(getString(R.string.แกงฮังเล));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงฮังเล");
        }
        if (foodName.equals("แกงหอยขม")) {
            textView.setText(getString(R.string.แกงหอยขม));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงหอยขม");
        }
        if (foodName.equals("ข้าวคลุกงา")) {
            textView.setText(getString(R.string.ข้าวคลุกงา));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("ข้าวคลุกงา");
        }
        if (foodName.equals("แหนมหูหมู")) {
            textView.setText(getString(R.string.แหนมหูหมู));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แหนมหูหมู");
        }
        if (foodName.equals("แกงกล้วยดิบ")) {
            textView.setText(getString(R.string.แกงกล้วยดิบ));
            textView.setLayoutParams(layoutParams);
            linearLayout.addView(textView);
            name_manu.setText("แกงกล้วยดิบ");
        }
        LinearLayout linearLayout1 = findViewById(R.id.shownuer);
        if (linearLayout1 != null) {
            linearLayout1.addView(scrollView);
        }

    }
}